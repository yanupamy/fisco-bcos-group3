import React from 'react';

class Success extends React.Component {
  render() {
    return (
    <h1>ErrorCode: {this.props.ErrorCode}</h1>
    <h1>ErrorMessage: {this.props.ErrorMessage}</h1>
    <h1>respBody: {this.props.respBody}</h1>
   );
  }
}

export default Success;
