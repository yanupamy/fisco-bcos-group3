import React, { Component } from "react";
import ReactDOM from "react-dom";

export default class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      values: {
        agency: "",
        password: ""
      },
      isSubmitting: false,
      isError: false
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.submitForm = this.submitForm.bind(this);

  }

  submitForm(event) {
    event.preventDefault();
    console.log(this.state);
    this.setState({ isSubmitting: true });

    if ((this.state.values.agency=="agency01" || this.state.values.agency==="agency02" || this.state.values.agency==="agency03") &&
        (this.state.values.password==="test"))
    {
        localStorage.setItem("CurrentAgency", this.state.values.agency);
        var agencyName='';
        if (this.state.values.agency==="agency01") {
            agencyName="恩主地產";
        } else if (this.state.values.agency==="agency01") {
            agencyName="榮昇地產投資有限公司";
        } else if (this.state.values.agency==="agency01") {
            agencyName="御城物業";
        }

        alert('Welcome ' + agencyName);

        this.setState({ isSubmitting: false });
    }

  };

  handleInputChange = e =>
    this.setState({
      values: { ...this.state.values, [e.target.name]: e.target.value }
    });

  render() {
    return (

      <div className="container">
      
        <form onSubmit={this.submitForm}>
          <div className="form-group">
            <label htmlFor="agency">Agency ID</label>
            <input className="form-control"
              type="text"
              name="agency"
              id="agency"
              value={this.state.values.agency}
              onChange={this.handleInputChange}
              title="Email"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input className="form-control"
              type="password"
              name="password"
              id="password"
              value={this.state.values.password}
              onChange={this.handleInputChange}
              title="password"
              required
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block">Sign In</button>


        </form>
        <div className={`message ${this.state.isError && "error"}`}>
          {this.state.isSubmitting ? "Submitting..." : this.state.message}
        </div>
      </div>
    );
  }
}
