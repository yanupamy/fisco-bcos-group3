import React, { Component } from 'react';
import ReactDOM from "react-dom";

class CreatePropertyInfoForm extends React.Component {
  propertyInfoData;
  constructor(props) {
    super(props);
    this.state = {
      values: {
        usageType: "",
        district:"",
        street: "",
        building:"",
        blockNo:"",
        floor:"",
        room: "",
        layout: "",
        grossArea: "",
        saleableArea:"",
        price: "",
        rental: "N",
        age: 0,
        includeElevator: "N",
        owner: "",
        ownerContact: "",
        remark: ""
      },
      isSubmitting: false,
      isError: false,
      WeID: "",
      ErrorCode: -1,
      ErrorMessage: "",
      respBody: ""
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  handleChange = (event) => {
    const {name, value} = event.target;

    this.setState((state) => ({
        values: {
          usageType: ((name=="usageType")?value:this.state.values.usageType),
          district:((name=="district")?value:this.state.values.district),
          street: ((name=="street")?value:this.state.values.street),
          building:((name=="building")?value:this.state.values.building),
          blockNo:((name=="blockNo")?value:this.state.values.blockNo),
          floor:((name=="floor")?value:this.state.values.floor),
          room: ((name=="room")?value:this.state.values.room),
          layout: ((name=="layout")?value:this.state.values.layout),
          grossArea: ((name=="grossArea")?value:this.state.values.grossArea),
          saleableArea:((name=="saleableArea")?value:this.state.values.saleableArea),
          price: ((name=="price")?value:this.state.values.price),
          rental: ((name=="rental")?value:this.state.values.rental),
          age: ((name=="age")?value:this.state.values.age),
          includeElevator: ((name=="includeElevator")?value:this.state.values.includeElevator),
          owner: ((name=="owner")?value:this.state.values.owner),
          ownerContact: ((name=="ownerContact")?value:this.state.values.ownerContact),
          remark: ((name=="remark")?value:this.state.values.remark)
        }
      }), () => {
        // alert('Set Property Info ' + name + ': ' + eval('this.state.values.'+name))
        console.log('Set Property Info ' + name + ': ' + eval('this.state.values.'+name));
      }
    )
  }

  componentDidMount() {
      // alert('componentDidMount');

      this.propertyInfoData = JSON.parse(localStorage.getItem('propertyInfo'));

      if (localStorage.getItem('propertyInfo')) {
          this.setState({
            values: {
              usageType: this.propertyInfoData.values.usageType,
              district: this.propertyInfoData.values.district,
              street: this.propertyInfoData.values.street,
              building: this.propertyInfoData.values.building,
              blockNo: this.propertyInfoData.values.blockNo,
              floor: this.propertyInfoData.values.floor,
              room: this.propertyInfoData.values.room,
              layout: this.propertyInfoData.values.layout,
              grossArea: this.propertyInfoData.values.grossArea,
              saleableArea: this.propertyInfoData.values.saleableArea,
              price: this.propertyInfoData.values.price,
              rental: this.propertyInfoData.values.rental,
              age: this.propertyInfoData.values.age,
              includeElevator: this.propertyInfoData.values.includeElevator,
              owner: this.propertyInfoData.values.owner,
              ownerContact: this.propertyInfoData.values.ownerContact,
              remark: this.propertyInfoData.values.remark
            }
          })
      } else {
          this.setState({
              values: {
                usageType: "",
                district:"",
                street: "",
                building:"",
                blockNo:"",
                floor:"",
                room: "",
                layout: "",
                grossArea: "",
                saleableArea:"",
                price: "",
                rental: "N",
                age: 0,
                includeElevator: "N",
                owner: "",
                ownerContact: "",
                remark: ""
              }
          })
      }
      // alert('componentDidMount: ' + this.state.values);
  }

  componentWillUpdate(nextProps, nextState) {
      localStorage.setItem('propertyInfo', JSON.stringify(nextState));
  }

  handleSubmit = async event => {

    this.propertyInfoData = JSON.parse(localStorage.getItem('propertyInfo'));
    alert('stored: ' + JSON.stringify(this.propertyInfoData));

    var claim = this.state.values;
    alert('values(claim): ' + claim);

    event.preventDefault();

    console.log(this.state);
    this.setState({
      isSubmitting: true
    });

    var submitBody = {
        "functionArg": {
            "issuer": "did:weid:0x5774e89d8e7fc8ffc1b7fff4b1019a22ac7140fb",
            "cptId": "1278",
            "expirationDate": "2500-04-18T21:12:33Z",
            "claim": this.propertyInfoData.values
        },
        "transactionArg": {
        	"invokerWeId": "did:weid:0x5774e89d8e7fc8ffc1b7fff4b1019a22ac7140fb"
        },
        "v": "1.0.0",
        "functionName": "createCredential"
    };

    alert('body: ' + JSON.stringify(submitBody));

    const res = await fetch("http://127.0.0.1:6001/weid/api/invoke", {
      method: "POST",
      body: JSON.stringify(submitBody),
      headers: {
        "Content-Type": "application/json"
      }
    });
    this.setState({ isSubmitting: false });
    const data = await res.json();
    if (data.hasOwnProperty("errorCode") && (data.errorCode===0)) {
      this.setState({ ErrorCode: data.errorCode, ErrorMessage: data.errorMessage, WeID: data.respBody })
      alert('WeID: ' + data.respBody);
    } else {
      this.setState({ ErrorMessage: "Failed", isError: true });
      alert('Failed');
    }

    setTimeout(
      () =>
        this.setState({
          isError: false,
          values: {
            usageType: "",
            district:"",
            street: "",
            building:"",
            blockNo:"",
            floor:"",
            room: "",
            layout: "",
            grossArea: "",
            saleableArea:"",
            price: "",
            rental: "N",
            age: 0,
            includeElevator: "N",
            owner: "",
            ownerContact: "",
            remark: ""
          }
        }),
      1600
    );
  };



  render() {
    return (
      <div className="container">

      <h1>樓盤資料</h1>
      <div className="form-group">
      <label>所屬地產公司:</label>
      <label>合盈地產(agency01)</label>
      </div>

      <form onSubmit={this.handleSubmit}>
        <div className="form-group">
        <label htmlFor="usageType">用途:</label>
          <select className="form-control"
            id="usageType" name="usageType"
            value={this.state.values.usageType}
            onChange={this.handleChange}>
            <option value="Resident">住宅</option>
            <option value="Office">辦公室</option>
          </select>
        </div>
        <div className="form-group">
        <label htmlFor="district">地區:</label>
        <input className="form-control"
          id="district" name="district"
          type="text" value={this.state.values.district} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="street">街道:</label>
        <input className="form-control"
          id="street" name="street"
          type="text" value={this.state.values.street} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="building">大廈:</label>
        <input className="form-control"
          id="building" name="building"
          type="text" value={this.state.values.building} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="blockNo">座:</label>
        <input className="form-control"
          id="blockNo" name="blockNo"
          type="text" value={this.state.values.blockNo} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="floor">單位:</label>
        <input className="form-control"
          id="floor" name="floor"
          type="text" value={this.state.values.floor} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="room">房間數:</label>
        <input className="form-control"
          id="room" name="room"
          type="text" value={this.state.values.room} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="layout">間隔: </label>
        <input className="form-control"
          id="layout" name="layout"
          type="text" value={this.state.values.layout} onChange={this.handleAddressChange} />
        </div>
        <div className="form-group">
        <label htmlFor="grossArea">建築面積:</label>
        <input className="form-control"
          id="grossArea" name="grossArea"
          type="text" value={this.state.values.grossArea} onChange={this.handleChange} />
          <label>(平方呎)</label>
        </div>
        <div className="form-group">
        <label htmlFor="saleableArea">實用面積:</label>
        <input className="form-control"
          id="saleableArea" name="saleableArea"
          type="text" value={this.state.values.saleableArea} onChange={this.handleChange} />
          <label>(平方呎)</label>
        </div>
        <div className="form-group">
        <label htmlFor="price">價格:</label>
        <input className="form-control"
          id="price" name="price"
          type="text" value={this.state.values.price} onChange={this.handleChange} />
          <label>(港元)</label>
        </div>
        <div className="form-group">
        <label htmlFor="rental">租:</label>
          <select className="form-control"
            id="rental" name="rental"
            value={this.state.values.rental}
            onChange={this.handleChange}>
            <option value="Y">是</option>
            <option value="N">否</option>
          </select>
        </div>
        <div className="form-group">
        <label htmlFor="price">樓齡:</label>
        <input className="form-control"
          id="age" name="age"
          type="text" value={this.state.values.age} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="includeElevator">是否電梯樓:</label>
          <select className="form-control"
            id="includeElevator" name="includeElevator"
            value={this.state.values.includeElevator}
            onChange={this.handleChange}>
            <option value="Y">是</option>
            <option value="N">否</option>
          </select>
        </div>
        <div className="form-group">
        <label htmlFor="owner">放盤人/業主 名稱:</label>
        <input className="form-control"
          id="owner" name="owner"
          type="text" value={this.state.values.owner} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="ownerContact">放盤人/業主 聯絡:</label>
        <input className="form-control"
          id="ownerContact" name="ownerContact"
          type="text" value={this.state.values.ownerContact} onChange={this.handleChange} />
        </div>
        <div className="form-group">
        <label htmlFor="remark">備註:</label>
        <textarea className="form-control"
          id="remark" name="remark"
          value={this.state.values.remark} onChange={this.handleChange} />
        </div>

        <input type="submit" value="Submit" />

      </form>

      </div>
    );
  }
}

export default CreatePropertyInfoForm;
