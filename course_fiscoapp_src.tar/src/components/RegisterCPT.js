import React, { Component } from 'react';
import ReactDOM from "react-dom";

class RegisterCptForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      WeID: "id:weid:0x44c8efec3ffa66890d81251fa86229e3d65f1775",
      ErrorCode: -1,
      ErrorMessage: "",
      respBody: ""
    };

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit = async event => {
    event.preventDefault();

    console.log(this.state);
    this.setState({ isSubmitting: true });

    var submitBody = {
        "functionArg": {
            "weId": this.state.WeID,
            "cptJsonSchema":{
                "title": "property cpt",
                "description": "this is property cpt",
                "properties": {
                    "usageType": {
                        "enum": [
                            "R",
                            "O"
                        ],
                        "type": "string",
                        "description": "the Usage Type of property用途"
                    },
                    "district": {
                        "type": "string",
                        "description": "District地區"
                    },
                    "street": {
                        "type": "string",
                        "description": "the Street name of property街道"
                    },
                    "building": {
                        "type": "string",
                        "description": "the Building name of property大廈名稱"
                    },
                    "blockNo": {
                        "type": "string",
                        "description": "the Block No of property座"
                    },
                    "floor": {
                        "type": "string",
                        "description": "Which Floor of property單位"
                    },
                    "room": {
                        "type": "string",
                        "description": "How many rooms of property房間數"
                    },
                    "layout": {
                        "type": "string",
                        "description": "the Layout of property間隔"
                    },
                    "grossArea": {
                        "type": "number",
                        "description": "the Gross Area (size in feet) of property建築面積"
                    },
                    "saleableArea": {
                        "type": "number",
                        "description": "the Gross Area (size in feet) of property實用面積"
                    },
                    "price": {
                        "type": "number",
                        "description": "the Sale Price of property價格"
                    },
                    "rental": {
                        "enum": [
                            "Y",
                            "N"
                        ],
                        "type": "string",
                        "description": "Is Rental"
                    },
                    "includeElevator": {
                        "enum": [
                            "Y",
                            "N"
                        ],
                        "type": "string",
                        "description": "Is Include Elevator是否電梯樓"
                    },
                    "owner": {
                        "type": "string",
                        "description": "the Owner of property放盤人業主 名稱"
                    },
                    "ownerContact": {
                        "type": "string",
                        "description": "the Owner Contact of property 放盤人業主 聯絡"
                    },
                    "age": {
                        "type": "number",
                        "description": "the age of certificate owner樓齡"
                    },
                    "remark": {
                        "type": "string",
                        "description": "the Remark of property備註"
                    }
                },
                "required": [
                    "usageType",
                    "building"
                ]
            }
        },
        "transactionArg": {
            "invokerWeId": this.state.WeID
        },
        "functionName": "registerCpt",
        "v": "1.0.0"
    };

    alert('body: ' + JSON.stringify(submitBody));

    const res = await fetch("http://127.0.0.1:6001/weid/api/invoke", {
      method: "POST",
      body: JSON.stringify(submitBody),
      headers: {
        "Content-Type": "application/json"
      }
    });
    this.setState({ isSubmitting: false });
    const data = await res.json();
    if (data.hasOwnProperty("errorCode") && (data.errorCode===0)) {
      this.setState({ ErrorCode: data.errorCode, ErrorMessage: data.errorMessage, WeID: data.respBody })
      alert('WeID: ' + data.respBody);
    } else {
      this.setState({ ErrorMessage: "Failed", isError: true });
      alert('Failed');
    }

    setTimeout(
      () =>
        this.setState({
          isError: false
        }),
      1600
    );
  };


  render() {
    return (
      <div className="container">

      <h1>Register CPT</h1>
      <form onSubmit={this.handleSubmit}>
        <input type="submit" value="Submit" />
      </form>

      </div>
    );
  }
}

export default RegisterCptForm;
