import React, { Component } from 'react';
import ReactDOM from "react-dom";

class CreateAgencyWeIdForm extends React.Component {
  agencyData;
  constructor(props) {
    super(props);
    this.state = {
      values: {
        agencyId: "",
        agencyName: "",
        agencyContact: "",
        agencyAddress: ""
      },
      isSubmitting: false,
      isError: false,
      WeID: "",
      ErrorCode: -1,
      ErrorMessage: "",
      respBody: ""
    };

    this.handleAgencyChange = this.handleAgencyChange.bind(this);
    this.handleContactChange = this.handleContactChange.bind(this);
    this.handleAddressChange = this.handleAddressChange.bind(this);
    // this.handleAgencyValues = this.handleAgencyValues.bind(this);

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleAgencyChange = (event) => {
    const {name, value} = event.target;

    var myAgencyName = "";
    var selectedIndex = event.target.selectedIndex;
    if (selectedIndex >= 0) {
      myAgencyName = event.target.options[selectedIndex].text;
      alert('Agency: ' + myAgencyName + " (" + event.target.value + ")");
    };

    //this.setState({
    //  values: {agencyId: event.target.value, agencyName: myAgencyName}
    //});

    this.setState((state) => ({
        values: {agencyId: value, agencyName: myAgencyName}
      }), () => {
        alert('Set Agency Name: ' + this.state.values.agencyName + "(" + this.state.values.agencyId+")")
      }
    )

    // this.handleAgencyValues();
    // alert('Set Agency Name: ' + this.state.values.agencyName + "(" + this.state.values.agencyId+")");
  }

  /*
  handleAgencyValues = () => {
    this.setState(state => {
      return {
        values: state.values,
      }
    });
  }
  */

  handleContactChange(event) {
    const {name, value} = event.target;
    // this.setState({values: {agencyContact: event.target.value}});
    this.setState((state) => ({
        values: {agencyContact: value}
      }), () => {
        alert('Set Agency Contact: ' + this.state.values.agencyContact )
      }
    )
  }

  handleAddressChange(event) {
    const {name, value} = event.target;

    this.setState((state) => ({
        values: {agencyAddress: value}
      }), () => {
        // alert('Set Agency Address: ' + this.state.values.agencyAddress )
        console.log( 'Set Agency Address: ' + this.state.values.agencyAddress );
      }
    )
  }

  // React Life Cycle

  componentDidMount() {
      // alert('componentDidMount');

      this.agencyData = JSON.parse(localStorage.getItem('agency'));

      if (localStorage.getItem('agency')) {
          this.setState({
            values: {
              agencyId: this.agencyData.values.agencyId,
              agencyName: this.agencyData.values.agencyName,
              agencyContact: this.agencyData.values.agencyContact,
              agencyAddress: this.agencyData.values.agencyAddress
            }
          })
      } else {
          this.setState({
              values: {
                agencyId: "",
                agencyName: "",
                agencyContact: "",
                agencyAddress: ""
              }
          })
      }
      // alert('componentDidMount: ' + this.state.values);
  }

  componentWillUpdate(nextProps, nextState) {
      // alert('componentWillUpdate: ' + JSON.stringify(nextState));
      localStorage.setItem('agency', JSON.stringify(nextState));
  }


  handleSubmit = async event => {
    alert('Your select: ' + this.state.values.agencyName);
    this.agencyData = JSON.parse(localStorage.getItem('agency'));
    alert('stored: ' + JSON.stringify(this.agencyData));

    event.preventDefault();

    console.log(this.state);
    this.setState({ isSubmitting: true });

    var submitBody = {
      "functionArg": {},
      "transactionArg": {},
      "functionName": 'createWeId',
      "v": '1.0.0'
    };

    alert('body: ' + JSON.stringify(submitBody));

    const res = await fetch("http://127.0.0.1:6001/weid/api/invoke", {
      method: "POST",
      body: JSON.stringify(submitBody),
      headers: {
        "Content-Type": "application/json"
      }
    });
    this.setState({ isSubmitting: false });
    const data = await res.json();
    if (data.hasOwnProperty("errorCode") && (data.errorCode===0)) {
      this.setState({ ErrorCode: data.errorCode, ErrorMessage: data.errorMessage, WeID: data.respBody })
      alert('WeID: ' + data.respBody);
    } else {
      this.setState({ ErrorMessage: "Failed", isError: true });
      alert('Failed');
    }

    setTimeout(
      () =>
        this.setState({
          isError: false,
          values: { agencyId: "", agencyName: "", agencyContact: "", agencyAddress: "" }
        }),
      1600
    );
  };



  render() {
    return (
      <div className="container">

      <h1>Create Agency WeID</h1>
      <form onSubmit={this.handleSubmit}>
        <div className="form-group">
        <label htmlFor="agency">地產公司:</label>
          <select className="form-control"
            id="agency" name="agency"
            value={this.state.values.agencyId}
            onChange={this.handleAgencyChange}>
            <option value=""></option>
            <option value="agency01">恩主地產</option>
            <option value="agency02">榮昇地產投資有限公司</option>
            <option value="agency03">御城物業</option>
            <option value="agency04">合盈地產</option>
          </select>
        </div>
        <div className="form-group">
        <label htmlFor="agencyContact">聯絡資料:</label>
        <input className="form-control"
          id="agencyContact" name="agencyContact"
          type="text" value={this.state.values.agencyContact} onChange={this.handleContactChange} />
        </div>

        <div className="form-group">
        <label htmlFor="agencyAddress">地址: </label>
        <input className="form-control"
          id="agencyAddress" name="agencyAddress"
          type="text" value={this.state.values.agencyAddress} onChange={this.handleAddressChange} />
        </div>

        <input type="submit" value="Submit" />
      </form>

      </div>
    );
  }
}

export default CreateAgencyWeIdForm;
