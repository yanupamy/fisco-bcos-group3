import React, { Component } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import CreateAgencyWeIdForm from './components/CreateAgencyWeId';
import CreatePropertyInfoForm from './components/CreatePropertyInfo';
import RegisterCptForm from './components/RegisterCPT';
import LoginForm from './components/SignIn';
import Home from './components/Home'
import Error from './components/Error';
import Navigation from './components/Navigation';

class App extends Component {
  render() {
    return (
      <BrowserRouter>
      <div>
        <Navigation />
          <Switch>
           <Route path="/" component={Home} exact/>
           <Route path="/SignIn" component={LoginForm}/>
           <Route path="/CreateAgencyWeId" component={CreateAgencyWeIdForm}/>
           <Route path="/RegisterCpt" component={RegisterCptForm}/>
           <Route path="/CreatePropertyInfo" component={CreatePropertyInfoForm}/>
          <Route component={Error}/>
         </Switch>
      </div>
    </BrowserRouter>
    );
  }
}

export default App;
